package es.iessoterohernandez.endes;

public class FibonacciMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Fibonacci f1 = new Fibonacci("Fibonacci 1",10);
        f1.mostrarSerie();
        
        Fibonacci f2 = new Fibonacci();
        f2.setNombr("fibonacci 2");
        f2.setTamaño(10);
        f2.mostrarSerie();
        
	}

}
